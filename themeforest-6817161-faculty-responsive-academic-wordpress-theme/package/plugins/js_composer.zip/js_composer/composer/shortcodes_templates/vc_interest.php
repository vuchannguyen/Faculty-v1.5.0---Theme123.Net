<?php
$output ='';
//
extract(shortcode_atts(array(
    'title' => '',
    'el_class' => ''
), $atts));

$el_class = $this->getExtraClass($el_class);
$css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'ul-boxed list-unstyled'.$el_class, $this->settings['base']);

$output='<ul class="'.$css_class.'">'.wpb_js_remove_wpautop($content).'</ul>';
echo $output;