<?php
$output = $project_title=$project_short_description=$project_image='';

extract(shortcode_atts(array(
	'project_title' 	=>'',
	'project_short_description'	=>'',
	'project_image'	=>''
), $atts));

$img_link=wp_get_attachment_image_src( $project_image, 'large') ;
$img_link=$img_link[0];

if ($img_link == ''){
	$img_link = get_template_directory_uri().'/img/project-default.png';
}

$output .='<li><div class="row">';
$output .= "\n\t\t\t\t" . '<div class="col-sm-6 col-md-3"><div class="image"><img src='.$img_link.' alt="'.$project_title.'" class="img-responsive">';
$output .='<div class="imageoverlay" style="left: 0px;"><i class="fa fa-search"></i></div></div></div>';
$output .='<div class="col-sm-6 col-md-9"><div class="meta"><h3>'.$project_title.'</h3><p>'.$project_short_description.'</p></div></div>';
$output .='</div>';
$output .= "\n\t\t".'<div class="details">';
$output .= "\n\t\t\t".wpb_js_remove_wpautop($content, true);
$output .= "\n\t\t".'</div> ';
$output .='</li>';
echo $output;
