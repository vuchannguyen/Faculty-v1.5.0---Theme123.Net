<?php
$output = $licon_des=$licon_class='';

extract(shortcode_atts(array(
	'licon_des' 	=>'',
	'licon_class'	=>''
), $atts));


$output .= "\n\t\t\t" . '<li>';
    $output .= "\n\t\t\t\t" . '<strong><i class="fa '.$licon_class.'"></i>&nbsp;&nbsp;</strong>';
    $output .= "\n\t\t\t\t" . '<span>'.$licon_des.'</span>';
    $output .= "\n\t\t\t" . '</li>';
echo $output;

