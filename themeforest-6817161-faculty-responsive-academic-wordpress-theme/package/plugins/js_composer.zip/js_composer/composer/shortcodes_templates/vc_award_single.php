<?php
$output = $award_title=$award_date=$award_content=$award_image='';

extract(shortcode_atts(array(
	'award_title' 	=>'sample award title',
	'award_date'	=>'2014',
	'award_content'	=>'sample content goes here',
	'award_image'   =>''
), $atts));

$css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, '', $this->settings['base']);

$img_link=wp_get_attachment_image_src( $award_image, 'large') ;
$img_link=$img_link[0];


if ($img_link){
    $content = '
    <div class="col-md-2">
        <img alt="image" class="thumbnail img-responsive" src="'.$img_link.'">
    </div>
    <div class="col-md-10">
        '.$award_content.'
    </div>';
}else{
    $content = '
    <div class="col-md-12">
        '.$award_content.'
    </div>';
}


$output .= "\n\t\t\t" . '<li class="'.$css_class.'">';
    $output .= "\n\t\t\t\t" . '<div class="date">'.$award_date.'</div>';
    $output .= "\n\t\t\t\t" . '<div class="circle"></div>';
    $output .= "\n\t\t\t\t" . '<div class="data"><div class="subject">'.$award_title.'</div><div class="text row">'.$content.'</div></div>';
    $output .= "\n\t\t\t" . '</li>';
echo $output;
