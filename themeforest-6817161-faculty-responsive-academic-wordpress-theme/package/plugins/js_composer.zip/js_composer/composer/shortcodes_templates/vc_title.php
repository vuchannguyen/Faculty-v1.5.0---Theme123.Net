<?php
$output = $title = $title_align = $el_class = '';
extract(shortcode_atts(array(
    'title' => __("Title", "js_composer"),
    'title_align' => 'text_center',
    'title_tag' => 'title_h3',
    'el_class' => ''
), $atts));
$el_class = $this->getExtraClass($el_class);

$class = ($title_tag == "big_head")? "fac-big-title fac-title" : "fac-title";

$css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class.' '.$title_align.$el_class, $this->settings['base']);

switch ($title_tag) {
	case 'big_head':
		$ot='<h1';
		$ct='</h1>';
		break;
	case 'title_h1':
		$ot='<h1';
		$ct='</h1>';
		break;
	case 'title_h2':
		$ot='<h2';
		$ct='</h2>';
		break;
	case 'title_h3':
		$ot='<h3';
		$ct='</h3>';
		break;
	case 'title_h4':
		$ot='<h4';
		$ct='</h4>';
		break;			
	
	default:
		$ot='<h3';
		$ct='</h3>';
		break;
}

$output .= $ot.' class="'.$css_class.'">'.$title.$ct.$this->endBlockComment('separator')."\n";
echo $output;