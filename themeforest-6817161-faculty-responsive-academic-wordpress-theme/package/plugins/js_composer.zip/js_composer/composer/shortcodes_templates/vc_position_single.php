<?php
$output = $pos_title=$pos_loc=$pos_start=$pos_end='';

extract(shortcode_atts(array(
	'pos_title' 	=>'sample position',
	'pos_loc'		=>'sample location',
	'pos_start'		=>'start',
	'pos_end'		=>'end'
), $atts));

$css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, '', $this->settings['base']);
$output .= "\n\t\t\t" . '<li class="'.$css_class.'">';
    $output .= "\n\t\t\t\t" . '<div class="dates"><span>'.$pos_end.'</span><span>'.$pos_start.'</span></div>';
    $output .= "\n\t\t\t\t" . '<div class="content"><h4>'.$pos_title.'</h4><p>'.$pos_loc.'</p></div>';
    $output .= "\n\t\t\t" . '</li>';
echo $output;
