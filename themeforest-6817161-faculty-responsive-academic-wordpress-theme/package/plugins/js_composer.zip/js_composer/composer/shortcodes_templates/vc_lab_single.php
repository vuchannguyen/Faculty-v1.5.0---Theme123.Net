<?php
$output = $pos_title=$pos_loc=$pos_start=$pos_end=$lab_follow='';

extract(shortcode_atts(array(
	'lab_name' 	=>'',
	'lab_pos'	=>'',
	'lab_image'	=>'',
	'lab_link'	=>'',
	'lab_follow' =>''
), $atts));

$img_link=wp_get_attachment_image_src( $lab_image, 'large') ;
$img_link=$img_link[0];

if ($lab_follow == ''){
	$lab_follow = "Follow";
}

$output .= "\n\t\t\t" . '<div class="dummy-lab-item">';
$output .= "\n\t\t\t\t" . '<div class="lab-item-image"><img src='.$img_link.' alt="'.$lab_name.'" class="img-circle lab-img"></div>';
$output .= "\n\t\t\t\t" . '<div class="lab-item-info"><h3>'.$lab_name.'</h3><h4>'.$lab_pos.'</h4>';
if (strlen($lab_link) >0)
	$output .= "\n\t\t\t\t" . '<a href="'.$lab_link.'" class="btn btn-info">'.$lab_follow.'</a>';
$output .= "\n\t\t\t" . '</div></div>';
echo $output;
