<?php
$output = $pos_title=$pos_loc=$pos_start=$pos_end='';

extract(shortcode_atts(array(
	'edu_title' 	=>'sample position',
	'edu_loc'		=>'sample location',
	'edu_level'		=>'lvl',
	'edu_year'		=>''
), $atts));

$css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, '', $this->settings['base']);
$output .= "\n\t\t\t" . '<li class="'.$css_class.'">';
$output .= "\n\t\t\t\t" . '<div class="dy"><span class="degree">'.$edu_level.'</span>';

if (strlen($edu_year)>1){
	$output .= "\n\t\t\t\t" .'<span class="year">'.$edu_year.'</span></div>';
}else{
	$output .= "\n\t\t\t\t" .'</div>';
}


$output .= "\n\t\t\t\t" . '<div class="description"><p class="what">'.$edu_title.'</p><p class="where">'.$edu_loc.'</p></div>';
$output .= "\n\t\t\t" . '</li>';
echo $output;
