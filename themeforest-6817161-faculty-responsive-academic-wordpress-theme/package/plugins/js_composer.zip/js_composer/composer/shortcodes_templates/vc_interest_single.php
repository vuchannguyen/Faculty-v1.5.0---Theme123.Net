<?php
$output = $interest_title='';

extract(shortcode_atts(array(
	'interest_title' 	=>''
), $atts));

$output .= '<li>'.$interest_title.'</li>';
    
echo $output;
