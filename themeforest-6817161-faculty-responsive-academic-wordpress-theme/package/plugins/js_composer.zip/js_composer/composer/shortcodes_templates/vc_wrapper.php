<?php
$output = $el_class = $wrapper_bgcolor = $wrapper_padding = $wrapper_margin='';
extract(shortcode_atts(array(
    'el_class'        => '',
    'wrapper_bgcolor'        => '',
    'wrapper_padding'         => '',
    'wrapper_margin'   => ''
), $atts));

$el_class = $this->getExtraClass($el_class);

$css_class =  apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'fac-wrapper '.get_row_css_class().$el_class, $this->settings['base']);

$style = 'style="padding:'.$wrapper_padding.';margin:'.$wrapper_margin.';background-color:'.$wrapper_bgcolor.';"';

$output .= '<div class="'.$css_class.'" '.$style.'>';
$output .= wpb_js_remove_wpautop($content);
$output .= '</div>';
echo $output;