<?php
$output = $licon_des=$licon_class='';

extract(shortcode_atts(array(
	'icon_class' 	=>'',
	'icon_size'		=>'',
	'icon_color' 	=>'',
	'icon_display'	=>'',
	'icon_align'	=>''

), $atts));


$output .='<i class="fa '.$icon_class.'" style="color:'.$icon_color.';font-size:'.$icon_size.'px ;display:'.$icon_display.';text-align:'.$icon_align.'"></i>';

echo $output;

