<?php 

class WPBakeryShortCode_Vc_wrapper extends WPBakeryShortCodesContainer {

}

class WPBakeryShortCode_Vc_position extends WPBakeryShortCodesContainer {
}
class WPBakeryShortCode_Vc_position_single extends WPBakeryShortCode {
}
class WPBakeryShortCode_Vc_education extends WPBakeryShortCodesContainer {
}
class WPBakeryShortCode_Vc_education_single extends WPBakeryShortCode {
}
class WPBakeryShortCode_Vc_award extends WPBakeryShortCodesContainer {
}
class WPBakeryShortCode_Vc_award_single extends WPBakeryShortCode {
}
class WPBakeryShortCode_Vc_lab extends WPBakeryShortCodesContainer {
}
class WPBakeryShortCode_Vc_lab_single extends WPBakeryShortCode {
}
class WPBakeryShortCode_Vc_interest extends WPBakeryShortCodesContainer {
}
class WPBakeryShortCode_Vc_interest_single extends WPBakeryShortCode {
}
class WPBakeryShortCode_Vc_project extends WPBakeryShortCodesContainer {
}
class WPBakeryShortCode_Vc_project_single extends WPBakeryShortCode {
	protected function outputTitle($title) {
        return  '';
    }
}
class WPBakeryShortCode_Vc_licon extends WPBakeryShortCodesContainer {
}
class WPBakeryShortCode_Vc_licon_single extends WPBakeryShortCode {
}
class WPBakeryShortCode_VC_single_icon extends WPBakeryShortCode {
	
}