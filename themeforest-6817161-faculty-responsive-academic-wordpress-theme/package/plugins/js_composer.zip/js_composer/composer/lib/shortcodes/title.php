<?php 
class WPBakeryShortCode_VC_Title extends WPBakeryShortCode {


    public function outputTitle($title) {
        return '';
    }
}
