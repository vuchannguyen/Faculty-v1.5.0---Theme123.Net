jQuery(function(jQuery) {
	
	
	jQuery('#media-items').bind('DOMNodeInserted',function(){
		jQuery('input[value="Insert into Post"]').each(function(){
				jQuery(this).attr('value','Use This');
		});
	});
	
	jQuery('.custom_upload_image_button').click(function() {
		formfield = jQuery(this).siblings('.custom_upload_image');
		preview = jQuery(this).siblings('.custom_preview_image');
		tb_show('', 'media-upload.php?type=image&TB_iframe=true');
		window.send_to_editor = function(html) {

			imgurl = jQuery('img',html).attr('src');
			classes = jQuery('img', html).attr('class');
			id = classes.replace(/(.*?)wp-image-/, '');
			formfield.val(id);
			preview.attr('src', imgurl);
			tb_remove();
		}
		return false;
	});
	
	jQuery('.custom_clear_image_button').click(function() {
		var defaultImage = jQuery(this).parent().siblings('.custom_default_image').text();
		jQuery(this).parent().siblings('.custom_upload_image').val('');
		jQuery(this).parent().siblings('.custom_preview_image').attr('src', defaultImage);
		return false;
	});

	jQuery('.custom_upload_file_button').click(function() {
		console.log('clicked');
		inputField = jQuery(this).siblings('.custom_upload_file');
		tb_show('', 'media-upload.php?TB_iframe=true');
		window.send_to_editor = function(html) {
			console.log(html);
			url = jQuery(html).attr('href');
			inputField.val(url);
			inputField.siblings('p').html('URL: <a target="_blank" href="'+ url +'">'+url+'</a>' );  
        	tb_remove();
		}
		return false;
	});
	jQuery('.custom_clear_file_button').click(function() {
		console.log('clicked');
		jQuery(this).parent().siblings('.custom_upload_image').val('');
		jQuery(this).parent().siblings('p').html('');
		return false;
	});

});